import { useState } from "react";

const nights = [
  { date: "April 23rd", day: "Wed", bottles: 47, bottlesUsed: 47, alertsFlagged: 2, bartendersOn: 3,
    byType: [{ label: "vodka", count: 14 }, { label: "tequila", count: 9 }, { label: "beer", count: 8 }, { label: "gin", count: 6 }, { label: "soju", count: 5 }],
    alerts: [{ type: "danger", text: "vodka overpour — 10 bottles vs 3 POS drinks", time: "11:42 PM" }, { type: "warning", text: "beer low stock — restocked at bar", time: "10:15 PM" }] },
  { date: "April 19th", day: "Sat", bottles: 81, bottlesUsed: 81, alertsFlagged: 1, bartendersOn: 4,
    byType: [{ label: "vodka", count: 22 }, { label: "beer", count: 18 }, { label: "tequila", count: 14 }, { label: "gin", count: 10 }, { label: "soju", count: 8 }],
    alerts: [{ type: "warning", text: "tequila low stock — restocked mid shift", time: "11:00 PM" }] },
  { date: "April 18th", day: "Fri", bottles: 74, bottlesUsed: 74, alertsFlagged: 0, bartendersOn: 3,
    byType: [{ label: "vodka", count: 20 }, { label: "beer", count: 16 }, { label: "gin", count: 12 }, { label: "tequila", count: 10 }, { label: "soju", count: 6 }],
    alerts: [] },
  { date: "April 12th", day: "Sat", bottles: 88, bottlesUsed: 88, alertsFlagged: 3, bartendersOn: 4,
    byType: [{ label: "vodka", count: 24 }, { label: "beer", count: 20 }, { label: "tequila", count: 16 }, { label: "gin", count: 14 }, { label: "soju", count: 8 }],
    alerts: [{ type: "danger", text: "vodka overpour — 8 bottles vs 2 POS drinks", time: "12:30 AM" }, { type: "warning", text: "gin low stock", time: "11:45 PM" }, { type: "warning", text: "beer low stock", time: "10:00 PM" }] },
  { date: "April 11th", day: "Fri", bottles: 66, bottlesUsed: 66, alertsFlagged: 0, bartendersOn: 3, byType: [{ label: "vodka", count: 18 }, { label: "beer", count: 14 }, { label: "tequila", count: 12 }, { label: "gin", count: 10 }, { label: "soju", count: 6 }], alerts: [] },
  { date: "April 5th", day: "Sat", bottles: 79, bottlesUsed: 79, alertsFlagged: 1, bartendersOn: 4, byType: [{ label: "vodka", count: 20 }, { label: "beer", count: 18 }, { label: "tequila", count: 14 }, { label: "gin", count: 8 }, { label: "soju", count: 7 }], alerts: [{ type: "danger", text: "rum overpour detected", time: "11:20 PM" }] },
  { date: "April 4th", day: "Fri", bottles: 71, bottlesUsed: 71, alertsFlagged: 0, bartendersOn: 3, byType: [{ label: "vodka", count: 19 }, { label: "beer", count: 15 }, { label: "tequila", count: 13 }, { label: "gin", count: 10 }, { label: "soju", count: 6 }], alerts: [] },
  { date: "March 29th", day: "Sat", bottles: 83, bottlesUsed: 83, alertsFlagged: 2, bartendersOn: 4, byType: [{ label: "vodka", count: 22 }, { label: "beer", count: 19 }, { label: "tequila", count: 15 }, { label: "gin", count: 12 }, { label: "soju", count: 8 }], alerts: [{ type: "danger", text: "vodka overpour detected", time: "12:00 AM" }, { type: "warning", text: "beer low stock", time: "10:30 PM" }] },
];

const ManagerDashboard = ({ onSettings, onCloseNight }) => {
  const [selectedNight, setSelectedNight] = useState(nights[0]);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const maxCount = Math.max(...selectedNight.byType.map((b) => b.count));

  return (
    <div style={styles.root}>

      {/* Top nav */}
      <div style={styles.nav}>
        <div style={styles.navLeft}>
          <button style={styles.sidebarToggle} onClick={() => setSidebarOpen(!sidebarOpen)}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2" strokeLinecap="round">
              <line x1="3" y1="6" x2="21" y2="6"/>
              <line x1="3" y1="12" x2="21" y2="12"/>
              <line x1="3" y1="18" x2="21" y2="18"/>
            </svg>
          </button>
          <div style={styles.logoWrap}>
            <img src="/logo.png" alt="OnTap" style={styles.logoImg} />
            <span style={styles.logoText}>OnTap</span>
          </div>
          <span style={styles.navTitle}>Manager Dashboard</span>
        </div>
        <div style={styles.navRight}>
          <button style={styles.closeNightBtn} onClick={onCloseNight}>Close for the Night</button>
          <button style={styles.settingsBtn} onClick={onSettings}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
            <span style={styles.settingsText}>Settings</span>
          </button>
        </div>
      </div>

      <div style={styles.body}>

        {/* Sidebar */}
        {sidebarOpen && (
          <div style={styles.sidebar}>
            <p style={styles.sidebarHeading}>Past Nights</p>
            {nights.map((night) => (
              <button
                key={night.date}
                style={{
                  ...styles.sidebarItem,
                  ...(selectedNight.date === night.date ? styles.sidebarItemActive : {}),
                }}
                onClick={() => setSelectedNight(night)}
              >
                <p style={{ ...styles.sidebarDate, color: selectedNight.date === night.date ? "#0d1f3c" : "#0d1f3c" }}>{night.date}</p>
                <p style={styles.sidebarSub}>{night.day} · {night.bottles} bottles</p>
              </button>
            ))}
          </div>
        )}

        {/* Main content */}
        <div style={styles.main}>

          {/* Night header */}
          <div style={styles.nightHeader}>
            <div>
              <h1 style={styles.nightTitle}>{selectedNight.date}</h1>
              <p style={styles.nightSub}>
                {selectedNight.day === "Wed" ? "Wednesday" : selectedNight.day === "Fri" ? "Friday" : selectedNight.day === "Sat" ? "Saturday" : selectedNight.day} · shift 9PM – 2AM
              </p>
            </div>
            <button style={styles.exportBtn}>export</button>
          </div>

          {/* Stats */}
          <div style={styles.statsRow}>
            <div style={styles.statBox}>
              <p style={styles.statLabel}>bottles used</p>
              <p style={styles.statNum}>{selectedNight.bottlesUsed}</p>
            </div>
            <div style={styles.statBox}>
              <p style={styles.statLabel}>alerts flagged</p>
              <p style={{ ...styles.statNum, color: selectedNight.alertsFlagged > 0 ? "#ef4444" : "#0d1f3c" }}>{selectedNight.alertsFlagged}</p>
            </div>
            <div style={styles.statBox}>
              <p style={styles.statLabel}>bartenders on</p>
              <p style={styles.statNum}>{selectedNight.bartendersOn}</p>
            </div>
          </div>

          {/* Bottles by type */}
          <div style={styles.section}>
            <p style={styles.sectionLabel}>bottles by type</p>
            <div style={styles.barList}>
              {selectedNight.byType.map((item) => (
                <div key={item.label} style={styles.barRow}>
                  <span style={styles.barLabel}>{item.label}</span>
                  <div style={styles.barTrack}>
                    <div style={{ ...styles.barFill, width: `${(item.count / maxCount) * 100}%` }} />
                  </div>
                  <span style={styles.barCount}>{item.count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Alerts */}
          <div style={styles.section}>
            <p style={styles.sectionLabel}>alerts that night</p>
            <div style={styles.alertList}>
              {selectedNight.alerts.length === 0 && (
                <p style={styles.noAlerts}>No alerts that night.</p>
              )}
              {selectedNight.alerts.map((alert, i) => (
                <div key={i} style={{
                  ...styles.alertRow,
                  background: alert.type === "danger" ? "#fee2e2" : "#fef9c3",
                  border: `1px solid ${alert.type === "danger" ? "#ef4444" : "#f59e0b"}`,
                }}>
                  <span style={{ ...styles.alertDot, background: alert.type === "danger" ? "#ef4444" : "#f59e0b" }} />
                  <span style={styles.alertText}>{alert.text}</span>
                  <span style={{ ...styles.alertTime, color: alert.type === "danger" ? "#ef4444" : "#f59e0b" }}>{alert.time}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

const styles = {
  root: { width: "100vw", height: "100vh", display: "flex", flexDirection: "column", fontFamily: "'Inter', sans-serif", background: "#f8f8f6", overflow: "hidden" },
  nav: { background: "#0d1f3c", padding: "14px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 },
  navLeft: { display: "flex", alignItems: "center", gap: "16px" },
  navRight: { display: "flex", alignItems: "center", gap: "12px" },
  sidebarToggle: { background: "none", border: "none", cursor: "pointer", padding: "4px", display: "flex", alignItems: "center" },
  logoWrap: { display: "flex", alignItems: "center", gap: "8px" },
  logoImg: { width: "28px", height: "28px", borderRadius: "6px", objectFit: "contain", background: "rgba(255,255,255,0.08)" },
  logoText: { fontFamily: "'Inter', sans-serif", fontSize: "16px", fontWeight: "600", color: "#ffffff" },
  navTitle: { fontFamily: "'Inter', sans-serif", fontSize: "13px", color: "#a8b8cc", borderLeft: "1px solid rgba(255,255,255,0.15)", paddingLeft: "16px" },
  closeNightBtn: { fontFamily: "'Inter', sans-serif", fontSize: "13px", fontWeight: "500", color: "#0d1f3c", background: "#ffffff", border: "none", borderRadius: "8px", padding: "8px 16px", cursor: "pointer" },
  settingsBtn: { display: "flex", alignItems: "center", gap: "6px", background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.15)", borderRadius: "8px", padding: "8px 14px", cursor: "pointer" },
  settingsText: { fontFamily: "'Inter', sans-serif", fontSize: "13px", color: "#ffffff" },
  body: { display: "flex", flex: 1, overflow: "hidden" },
  sidebar: { width: "220px", minWidth: "220px", background: "#f0ede8", borderRight: "1px solid #e5e7eb", overflowY: "auto", padding: "20px 0" },
  sidebarHeading: { fontFamily: "'Inter', sans-serif", fontSize: "11px", fontWeight: "600", color: "#9ca3af", letterSpacing: "0.08em", textTransform: "uppercase", padding: "0 20px 12px" },
  sidebarItem: { width: "100%", background: "transparent", border: "none", padding: "12px 20px", textAlign: "left", cursor: "pointer", borderLeft: "3px solid transparent" },
  sidebarItemActive: { background: "#ffffff", borderLeft: "3px solid #0d1f3c" },
  sidebarDate: { fontFamily: "'Inter', sans-serif", fontSize: "14px", fontWeight: "500", margin: "0 0 2px", color: "#0d1f3c" },
  sidebarSub: { fontFamily: "'Inter', sans-serif", fontSize: "12px", color: "#9ca3af", margin: 0 },
  main: { flex: 1, overflowY: "auto", padding: "32px 40px" },
  nightHeader: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "28px" },
  nightTitle: { fontFamily: "'Inter', sans-serif", fontSize: "28px", fontWeight: "600", color: "#0d1f3c", margin: "0 0 4px", letterSpacing: "-0.02em" },
  nightSub: { fontFamily: "'Inter', sans-serif", fontSize: "13px", color: "#6b7280", margin: 0 },
  exportBtn: { fontFamily: "'Inter', sans-serif", fontSize: "13px", color: "#0d1f3c", background: "transparent", border: "1px solid #d1d5db", borderRadius: "8px", padding: "8px 18px", cursor: "pointer" },
  statsRow: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", border: "1px solid #e5e7eb", borderRadius: "12px", overflow: "hidden", marginBottom: "28px", background: "#fff" },
  statBox: { padding: "20px 24px", borderRight: "1px solid #e5e7eb" },
  statLabel: { fontFamily: "'Inter', sans-serif", fontSize: "12px", color: "#6b7280", margin: "0 0 6px" },
  statNum: { fontFamily: "'Inter', sans-serif", fontSize: "36px", fontWeight: "600", color: "#0d1f3c", margin: 0, letterSpacing: "-0.02em" },
  section: { background: "#ffffff", border: "1px solid #e5e7eb", borderRadius: "12px", padding: "20px 24px", marginBottom: "20px" },
  sectionLabel: { fontFamily: "'Inter', sans-serif", fontSize: "12px", color: "#6b7280", margin: "0 0 16px" },
  barList: { display: "flex", flexDirection: "column", gap: "10px" },
  barRow: { display: "flex", alignItems: "center", gap: "12px" },
  barLabel: { fontFamily: "'Inter', sans-serif", fontSize: "13px", color: "#374151", width: "60px", flexShrink: 0 },
  barTrack: { flex: 1, height: "8px", background: "#f3f4f6", borderRadius: "4px", overflow: "hidden" },
  barFill: { height: "100%", background: "#0d1f3c", borderRadius: "4px", transition: "width 0.4s ease" },
  barCount: { fontFamily: "'Inter', sans-serif", fontSize: "13px", color: "#0d1f3c", fontWeight: "500", width: "24px", textAlign: "right" },
  alertList: { display: "flex", flexDirection: "column", gap: "8px" },
  noAlerts: { fontFamily: "'Inter', sans-serif", fontSize: "13px", color: "#9ca3af", margin: 0 },
  alertRow: { display: "flex", alignItems: "center", gap: "10px", padding: "12px 16px", borderRadius: "8px" },
  alertDot: { width: "8px", height: "8px", minWidth: "8px", borderRadius: "50%" },
  alertText: { fontFamily: "'Inter', sans-serif", fontSize: "13px", color: "#0d1f3c", flex: 1 },
  alertTime: { fontFamily: "'Inter', sans-serif", fontSize: "12px", fontWeight: "500", whiteSpace: "nowrap" },
};

export default ManagerDashboard;
