import { useState } from "react";

const BartenderDashboard = ({ staffName = "Nick", onClockOut }) => {
  const [bottles, setBottles] = useState([
    { id: "beer", label: "beer", count: 2, alert: "low", alertTitle: "GET MORE BEER", alertSub: "only 2 left — grab from back now", isKeg: false },
    { id: "vodka", label: "vodka", count: 10, alert: "overpour", alertTitle: "WATCH OVERPOUR", alertSub: "10 bottles, only 3 drinks on POS", isKeg: false },
    { id: "tequila", label: "tequila", count: 2, alert: null, isKeg: false },
    { id: "gin", label: "gin", count: 1, alert: null, isKeg: false },
    { id: "keg", label: "keg", count: null, alert: "keg", alertTitle: "CHECK KEG A", alertSub: "running low — weigh and update", isKeg: true },
    { id: "soju", label: "soju", count: 0, alert: null, isKeg: false },
  ]);

  const totalBottles = bottles.reduce((sum, b) => sum + (b.count || 0), 0);

  const tap = (id) => {
    setBottles((prev) => prev.map((b) => b.id === id ? { ...b, count: (b.count || 0) + 1 } : b));
  };

  const undo = (id) => {
    setBottles((prev) => prev.map((b) => b.id === id && b.count > 0 ? { ...b, count: b.count - 1 } : b));
  };

  const getCardStyle = (alert) => {
    if (alert === "low") return { background: "#fef9c3", border: "1.5px solid #f59e0b" };
    if (alert === "overpour") return { background: "#fee2e2", border: "1.5px solid #ef4444" };
    if (alert === "keg") return { background: "#eff6ff", border: "1.5px solid #3b82f6" };
    return { background: "#ffffff", border: "1px solid #e5e7eb" };
  };

  const getAlertStyle = (alert) => {
    if (alert === "low") return { background: "#f59e0b", color: "#1a0f00" };
    if (alert === "overpour") return { background: "#ef4444", color: "#ffffff" };
    if (alert === "keg") return { background: "#3b82f6", color: "#ffffff" };
    return {};
  };

  const now = new Date();
  const dateStr = now.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });

  return (
    <div style={styles.root}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.avatar}>
            <span style={styles.avatarLetter}>{staffName.charAt(0)}</span>
          </div>
          <div>
            <p style={styles.helloText}>hello, {staffName}</p>
            <p style={styles.shiftText}>shift started 9:00 PM · {dateStr}</p>
          </div>
        </div>
        <div style={styles.headerRight}>
          <p style={styles.bottlesLabel}>bottles used</p>
          <p style={styles.bottlesCount}>{totalBottles}</p>
          <button style={styles.clockOut} onClick={onClockOut}>clock out</button>
        </div>
      </div>

      {/* Subtitle */}
      <p style={styles.subtitle}>tap when a bottle is finished</p>

      {/* Grid */}
      <div style={styles.grid}>
        {bottles.map((bottle) => {
          const cardStyle = getCardStyle(bottle.alert);
          const alertStyle = getAlertStyle(bottle.alert);
          return (
            <div key={bottle.id} style={{ ...styles.card, ...cardStyle }}>
              <div style={styles.cardHeader}>
                <span style={styles.cardLabel}>{bottle.label}</span>
                <button style={styles.undoBtn} onClick={() => undo(bottle.id)}>undo</button>
              </div>
              <p style={styles.cardCount}>{bottle.count !== null ? bottle.count : "—"}</p>
              {bottle.alert && (
                <div style={{ ...styles.alertBanner, ...alertStyle }}>
                  <p style={styles.alertTitle}>{bottle.alertTitle}</p>
                  <p style={styles.alertSub}>{bottle.alertSub}</p>
                </div>
              )}
              <button style={styles.doneBtn} onClick={() => tap(bottle.id)}>
                {bottle.isKeg ? "keg checked" : "bottle done"}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const styles = {
  root: {
    width: "100vw",
    minHeight: "100vh",
    background: "#0d1f3c",
    fontFamily: "'Inter', sans-serif",
    display: "flex",
    flexDirection: "column",
    overflow: "auto",
  },
  header: {
    background: "#ffffff",
    borderBottom: "1px solid #e5e7eb",
    padding: "16px 32px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerLeft: {
    display: "flex",
    alignItems: "center",
    gap: "14px",
  },
  avatar: {
    width: "40px",
    height: "40px",
    borderRadius: "50%",
    background: "#0d1f3c",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  avatarLetter: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "15px",
    fontWeight: "600",
    color: "#ffffff",
  },
  helloText: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "15px",
    fontWeight: "600",
    color: "#0d1f3c",
    margin: "0 0 2px",
  },
  shiftText: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "12px",
    color: "#6b7280",
    margin: 0,
  },
  headerRight: {
    display: "flex",
    alignItems: "center",
    gap: "20px",
    textAlign: "right",
  },
  bottlesLabel: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "11px",
    color: "#6b7280",
    margin: 0,
    textAlign: "right",
  },
  bottlesCount: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "28px",
    fontWeight: "600",
    color: "#0d1f3c",
    margin: 0,
    lineHeight: "1",
  },
  clockOut: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "12px",
    color: "#6b7280",
    background: "transparent",
    border: "1px solid #e5e7eb",
    borderRadius: "6px",
    padding: "6px 14px",
    cursor: "pointer",
  },
  subtitle: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "13px",
    color: "#a8b8cc",
    margin: "20px 32px 12px",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: "16px",
    padding: "0 32px 32px",
    flex: 1,
  },
  card: {
    borderRadius: "14px",
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardLabel: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "18px",
    fontWeight: "600",
    color: "#0d1f3c",
    letterSpacing: "-0.01em",
  },
  undoBtn: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "12px",
    color: "#9ca3af",
    background: "none",
    border: "none",
    cursor: "pointer",
    padding: 0,
  },
  cardCount: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "48px",
    fontWeight: "600",
    color: "#0d1f3c",
    margin: 0,
    lineHeight: "1",
  },
  alertBanner: {
    borderRadius: "8px",
    padding: "10px 14px",
  },
  alertTitle: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "16px",
    fontWeight: "700",
    margin: "0 0 4px",
    letterSpacing: "0.02em",
  },
  alertSub: {
    fontFamily: "'Inter', sans-serif",
    fontSize: "13px",
    margin: 0,
    opacity: 0.9,
  },
  doneBtn: {
    width: "100%",
    padding: "13px",
    background: "#0d1f3c",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    fontSize: "14px",
    fontWeight: "600",
    fontFamily: "'Inter', sans-serif",
    cursor: "pointer",
    marginTop: "auto",
  },
};

export default BartenderDashboard;
